import React, { useState } from "react";
import { ArrowLeft, Plus, Wallet, PiggyBank, Briefcase, PlusCircle, ArrowRight, MinusCircle } from "lucide-react";
import { Bolsillo, BankAccount } from "../types";

interface BolsillosViewProps {
  accounts: BankAccount[];
  bolsillos: Bolsillo[];
  onUpdateBolsillo: (bolsilloId: string, savedAmount: number) => void;
  onAddBolsillo: (name: string, targetAmount: number, category: string) => void;
  onClose: () => void;
}

export default function BolsillosView({
  accounts,
  bolsillos,
  onUpdateBolsillo,
  onAddBolsillo,
  onClose
}: BolsillosViewProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPocketName, setNewPocketName] = useState("");
  const [newPocketTarget, setNewPocketTarget] = useState("");
  const [newPocketCat, setNewPocketCat] = useState("Ahorro");

  const [selectedPocketId, setSelectedPocketId] = useState<string | null>(null);
  const [pocketTransferType, setPocketTransferType] = useState<"in" | "out">("in"); // "in": savings to pocket, "out": pocket to savings
  const [transferAmountInput, setTransferAmountInput] = useState("");
  const [errorPocket, setErrorPocket] = useState("");

  const activePocket = bolsillos.find(p => p.id === selectedPocketId);
  const savingsAccount = accounts[0]; // primary savings account

  const handleCreatePocket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPocketName.trim()) return;
    const tgt = parseFloat(newPocketTarget.replace(/\D/g, "")) || 0;
    onAddBolsillo(newPocketName, tgt, newPocketCat);
    setNewPocketName("");
    setNewPocketTarget("");
    setShowAddForm(false);
  };

  const handlePocketTransfer = () => {
    setErrorPocket("");
    if (!activePocket || !savingsAccount) return;

    const amt = parseFloat(transferAmountInput.replace(/\D/g, "")) || 0;
    if (amt <= 0) {
      setErrorPocket("Digita un monto válido.");
      return;
    }

    if (pocketTransferType === "in") {
      // transfer from savings to pocket
      if (amt > savingsAccount.balance) {
        setErrorPocket("No tienes suficiente saldo disponible en tu cuenta de Ahorros.");
        return;
      }
      onUpdateBolsillo(activePocket.id, activePocket.savedAmount + amt);
    } else {
      // transfer out from pocket back to savings
      if (amt > activePocket.savedAmount) {
        setErrorPocket("No puedes retirar más de lo que has guardado en este bolsillo.");
        return;
      }
      onUpdateBolsillo(activePocket.id, activePocket.savedAmount - amt);
    }

    setTransferAmountInput("");
    setSelectedPocketId(null);
  };

  const formatCurrency = (val: number) => `$ ${val.toLocaleString("es-CO")}`;

  return (
    <div className="flex flex-col h-full bg-[#121212] text-neutral-200" id="bolsillos-wizard">
      {/* Header bar */}
      <div className="px-4 py-3 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between shrink-0">
        <button
          onClick={selectedPocketId ? () => setSelectedPocketId(null) : onClose}
          className="p-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-yellow-400 cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold text-neutral-100 uppercase tracking-wider">
          {selectedPocketId ? "Ajustar Bolsillo" : "Mis Bolsillos"}
        </span>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="p-1 text-yellow-400 hover:text-yellow-300 cursor-pointer"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {selectedPocketId && activePocket ? (
          /* Transfer money into or out of pocket view */
          <div className="space-y-4" id="pocket-management-panel">
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl text-center space-y-1">
              <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider">Bolsillo Seleccionado</span>
              <h3 className="text-sm font-bold text-neutral-200">{activePocket.name}</h3>
              <p className="text-yellow-400 font-mono font-bold text-lg">{formatCurrency(activePocket.savedAmount)}</p>
              
              <div className="w-full h-2 bg-zinc-950 rounded-full overflow-hidden mt-3 max-w-[200px] mx-auto">
                <div 
                  className="h-full bg-yellow-400 rounded-full" 
                  style={{ width: `${Math.min(100, (activePocket.savedAmount / (activePocket.targetAmount || 1)) * 100)}%` }} 
                />
              </div>
              <span className="text-[10px] text-zinc-500 block pt-1">Meta: {formatCurrency(activePocket.targetAmount)}</span>
            </div>

            {/* Transfer transaction directions selector */}
            <div className="grid grid-cols-2 p-1 bg-zinc-950 rounded-xl border border-zinc-800" id="pocket-directions-tabs">
              <button
                type="button"
                onClick={() => setPocketTransferType("in")}
                className={`py-2 text-[10px] font-bold uppercase rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  pocketTransferType === "in" ? "bg-yellow-400 text-black font-bold shadow" : "text-zinc-400 hover:text-white"
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" /> Enviar Dinero
              </button>
              <button
                type="button"
                onClick={() => setPocketTransferType("out")}
                className={`py-2 text-[10px] font-bold uppercase rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                  pocketTransferType === "out" ? "bg-yellow-400 text-black font-bold shadow" : "text-zinc-400 hover:text-white"
                }`}
              >
                <MinusCircle className="w-3.5 h-3.5" /> Retirar Dinero
              </button>
            </div>

            {/* Form */}
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-3">
              <div className="space-y-1">
                <label className="text-[9px] text-zinc-500 uppercase font-bold">Monto a cargar o retirar</label>
                <input
                  type="text"
                  placeholder="Digital valor"
                  value={transferAmountInput}
                  onChange={(e) => {
                    const clean = e.target.value.replace(/\D/g, "");
                    setTransferAmountInput(clean ? parseInt(clean).toLocaleString("es-CO") : "");
                  }}
                  className="w-full bg-zinc-950 text-xs px-3 py-2.5 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 font-mono"
                />
                <span className="text-[9px] text-zinc-500 block pt-0.5">
                  {pocketTransferType === "in" 
                    ? `Saldo disponible en Ahorros: ${formatCurrency(savingsAccount?.balance || 0)}`
                    : `Guardado en este bolsillo: ${formatCurrency(activePocket.savedAmount)}`
                  }
                </span>
              </div>

              {errorPocket && (
                <p className="text-rose-400 text-[10px] text-center font-medium">{errorPocket}</p>
              )}

              <button
                onClick={handlePocketTransfer}
                className="w-full py-2.5 bg-yellow-400 hover:bg-yellow-500 font-bold text-black rounded-xl text-xs tracking-wider uppercase transition-colors cursor-pointer"
              >
                {pocketTransferType === "in" ? "Enviar a mi bolsillo" : "Retirar a mi Cuenta"}
              </button>
            </div>
          </div>
        ) : showAddForm ? (
          /* Create new bolsillo pocket form */
          <form onSubmit={handleCreatePocket} className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-3.5" id="pocket-creation-form">
            <h4 className="text-xs font-bold text-neutral-200 flex items-center gap-2">
              <Wallet className="w-4 h-4 text-yellow-400" /> Crear un nuevo Bolsillo
            </h4>
            
            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 uppercase font-bold">Nombre del Bolsillo</label>
              <input
                type="text"
                placeholder="Ej. Vacaciones, Regalos, Seguro Auto"
                value={newPocketName}
                onChange={(e) => setNewPocketName(e.target.value)}
                className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-700"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 uppercase font-bold">Meta de Ahorro ($)</label>
              <input
                type="text"
                placeholder="0.00"
                value={newPocketTarget}
                onChange={(e) => {
                  const num = e.target.value.replace(/\D/g, "");
                  setNewPocketTarget(num ? parseInt(num).toLocaleString("es-CO") : "");
                }}
                className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-700 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 uppercase font-bold">Categoría</label>
              <select
                value={newPocketCat}
                onChange={(e) => setNewPocketCat(e.target.value)}
                className="w-full bg-zinc-950 text-xs px-3 py-2.5 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400"
              >
                <option value="Ahorro">Ahorro General</option>
                <option value="Viajes">Viajes</option>
                <option value="Hogar">Hogar y Arriendo</option>
                <option value="Estudios">Educación</option>
                <option value="Salud">Salud y Bienestar</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="submit"
                className="py-2.5 bg-yellow-400 hover:bg-yellow-300 font-bold text-black rounded-xl text-xs tracking-wider uppercase cursor-pointer"
              >
                Crear
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="py-2.5 bg-transparent border border-zinc-800 text-zinc-500 font-bold rounded-xl text-xs uppercase cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </form>
        ) : (
          /* List of pockets catalog view */
          <div className="space-y-4" id="pockets-list-panel">
            <p className="text-[10px] text-neutral-500 leading-normal">
              Los <strong className="text-yellow-400">bolsillos</strong> te permiten apartar dinero de tu cuenta de ahorros para metas de forma segura. No se puede gastar hasta que lo retires.
            </p>

            {bolsillos.length === 0 ? (
              <div className="text-center py-12 bg-zinc-900 border border-zinc-800 rounded-2xl" id="empty-pockets">
                <PiggyBank className="w-10 h-10 text-zinc-700 mx-auto mb-2" />
                <p className="text-xs text-zinc-500">No tienes bolsillos de ahorro creados de momento.</p>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="mt-3.5 px-3 py-1.5 bg-yellow-400 text-black text-[10px] font-bold rounded-lg uppercase cursor-pointer"
                >
                  Crear Primer Bolsillo
                </button>
              </div>
            ) : (
              <div className="space-y-2.5" id="pockets-cards-grid">
                {bolsillos.map((pocket) => {
                  const target = pocket.targetAmount || 1;
                  const percent = Math.min(100, Math.round((pocket.savedAmount / target) * 100));

                  return (
                    <div
                      key={pocket.id}
                      onClick={() => setSelectedPocketId(pocket.id)}
                      className="p-3.5 bg-zinc-900 border border-zinc-800 hover:border-yellow-400 rounded-2xl cursor-pointer transition-all flex justify-between items-center gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-neutral-100 truncate">{pocket.name}</span>
                          <span className="text-[9px] px-1.5 py-0.2 bg-zinc-800 text-zinc-400 rounded-full">
                            {pocket.category}
                          </span>
                        </div>

                        <div className="flex justify-between text-[10px] text-zinc-400 mt-1 font-mono">
                          <span>Guardado: {formatCurrency(pocket.savedAmount)}</span>
                          <span>Meta: {formatCurrency(pocket.targetAmount)}</span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-1.5 bg-zinc-950 rounded-full mt-2 overflow-hidden">
                          <div
                            className="bg-yellow-400 h-full rounded-full transition-all duration-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-bold text-yellow-400 pr-1">{percent}%</span>
                        <ArrowRight className="w-4 h-4 text-zinc-700 inline-block" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
