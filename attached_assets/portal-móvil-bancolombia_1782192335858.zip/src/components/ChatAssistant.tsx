import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, CornerDownRight, Sparkles, AlertCircle, Loader2 } from "lucide-react";
import { ChatMessage, BankAccount } from "../types";

interface ChatAssistantProps {
  accounts: BankAccount[];
  onSimulateTransfer?: (amount: number, dest: string) => void;
  onClose?: () => void;
}

export default function ChatAssistant({
  accounts,
  onSimulateTransfer,
  onClose
}: ChatAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "assistant",
      content: "¡Hola, Alejandra! Soy Tabby, tu Asistente Virtual Inteligente de Bancolombia. 🇨🇴🐾 \n\n¿En qué te puedo asesorar hoy? Puedo ayudarte a consultar tus saldos, darte consejos financieros personalizados, explicarte cómo usar el portal o simular un pago o transferencia.",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent, presetText?: string) => {
    if (e) e.preventDefault();
    const textToSend = presetText || input.trim();
    if (!textToSend || loading) return;

    if (!presetText) setInput("");
    setError(null);

    // Add user message
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: textToSend,
      timestamp: new Date()
    };
    
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setLoading(true);

    try {
      // Map message log to what server expects: [{ role: 'user' | 'assistant', content: '...' }]
      const historyPayload = messages.map(m => ({
        role: m.role,
        content: m.content
      }));

      // Call our secure full-stack backend Chat endpoint
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          history: historyPayload
        })
      });

      if (!response.ok) {
        throw new Error("Error en la conexión con el servidor de IA.");
      }

      const data = await response.json();
      
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.text,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMsg]);

      // Detect if AI suggested a transfer or check balance just to trigger cool interactions
      // e.g. "transferir", "saldo de ahorros", etc.
      if (onSimulateTransfer && textToSend.toLowerCase().includes("transf")) {
        // Trigger a tiny hints or parse simulation
      }

    } catch (err: any) {
      console.error(err);
      setError("No se pudo conectar con Gemini. Por favor, verifica que tu clave API de Gemini esté cargada en Settings > Secrets.");
      // Fallback response so the app never feels broken
      const botFallback: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Estimado cliente, de momento no puedo acceder a mi módulo cognitivo principal (error de API Key). \n\nNo obstante, puedo informarte que cuentas con un saldo disponible de **$2.654.112,00 COP** en tu cuenta de Ahorros. ¿Deseas que simulemos una transferencia de manera directa?",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botFallback]);
    } finally {
      setLoading(false);
    }
  };

  const presets = [
    { label: "💳 Ver saldos", text: "¿Cuál es mi saldo actual y qué cuentas tengo?" },
    { label: "🔒 Explicar Clave Dinámica", text: "¿Para qué sirve y cómo funciona la Clave Dinámica?" },
    { label: "📊 Consejos para ahorrar", text: "Dame 3 consejos prácticos de ahorro para mi presupuesto este mes." },
    { label: "🚀 Simular Transferencia", text: "Quiero simular una transferencia" }
  ];

  return (
    <div className="flex flex-col h-full bg-[#121212] text-neutral-200" id="chat-assistant-container">
      {/* Mini Headers info */}
      <div className="px-4 py-2 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between" id="chat-header">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center text-black font-bold">
            <Bot className="w-4 h-4 text-black" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-neutral-100 flex items-center gap-1">
              Tabby AI <Sparkles className="w-3 h-3 text-yellow-400 fill-yellow-400" />
            </h4>
            <span className="text-[10px] text-emerald-400">● En línea • Seguro</span>
          </div>
        </div>
        <span className="text-[10px] font-mono text-zinc-500">Móvil Bancolombia</span>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" id="chat-messages-scroll">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div className={`max-w-[85%] flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
              <div className={`w-6 h-6 rounded-full shrink-0 flex items-center justify-center text-[10px] ${
                msg.role === "user" ? "bg-zinc-700 text-white" : "bg-neutral-800 text-yellow-400"
              }`}>
                {msg.role === "user" ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>
              <div className={`rounded-2xl px-3.5 py-2.5 text-xs shadow-sm whitespace-pre-line leading-relaxed ${
                msg.role === "user" 
                  ? "bg-yellow-400 text-stone-950 font-normal rounded-tr-none" 
                  : "bg-zinc-900 text-neutral-200 border border-zinc-800/80 rounded-tl-none"
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="max-w-[85%] flex gap-2">
              <div className="w-6 h-6 rounded-full shrink-0 flex items-center justify-center bg-neutral-800 text-yellow-400">
                <Bot className="w-3.5 h-3.5" />
              </div>
              <div className="bg-zinc-900 text-neutral-400 rounded-2xl rounded-tl-none px-4 py-2 text-xs border border-zinc-800 flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-yellow-400" />
                <span>Tabby está pensando...</span>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl flex gap-2 text-[11px] text-red-200">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Preset Suggestions */}
      <div className="p-2 border-t border-zinc-800/50 bg-[#121212] overflow-x-auto whitespace-nowrap flex gap-1.5 scrollbar-none" id="chat-presets">
        {presets.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(undefined, preset.text)}
            className="px-2.5 py-1.5 bg-zinc-950 text-neutral-300 rounded-lg text-[10px] border border-zinc-800 hover:border-yellow-400 hover:text-white transition-all cursor-pointer shrink-0"
          >
            {preset.label}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="p-3 bg-zinc-900 border-t border-zinc-800 flex gap-2 z-10" id="chat-form">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Pregúntale a Tabby..."
          disabled={loading}
          className="flex-1 bg-zinc-950 border border-zinc-800 text-xs px-3 py-2 rounded-xl text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-500 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="w-9 h-9 bg-yellow-400 rounded-xl flex items-center justify-center text-black hover:bg-yellow-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer shrink-0"
        >
          <Send className="w-4.5 h-4.5" />
        </button>
      </form>
    </div>
  );
}
