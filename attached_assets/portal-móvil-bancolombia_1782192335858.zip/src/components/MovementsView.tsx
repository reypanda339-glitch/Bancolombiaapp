import React, { useState } from "react";
import { Search, ArrowUpRight, ArrowDownLeft, X, Filter, Sparkles } from "lucide-react";
import { BankMovement } from "../types";

interface MovementsViewProps {
  movements: BankMovement[];
  onClose: () => void;
}

export default function MovementsView({ movements, onClose }: MovementsViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("TODAS");

  const categories = ["TODAS", "Mercado", "Entretenimiento", "Servicios", "Transferencia", "Nómina", "Otros"];

  const filteredMovements = movements.filter((mov) => {
    const matchesSearch = mov.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "TODAS" || mov.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Calculate stats for custom visuals
  const totalIngresos = movements
    .filter((m) => m.type === "ingreso")
    .reduce((sum, m) => sum + m.amount, 0);

  const totalEgresos = movements
    .filter((m) => m.type === "egreso")
    .reduce((sum, m) => sum + m.amount, 0);

  // Group by category for visual graph representation
  const categorySummary = categories
    .filter((c) => c !== "TODAS")
    .map((cat) => {
      const amtByCat = movements
        .filter((m) => m.category === cat && m.type === "egreso")
        .reduce((sum, m) => sum + m.amount, 0);
      return { category: cat, amount: amtByCat };
    })
    .filter((c) => c.amount > 0);

  const maxExpense = Math.max(...categorySummary.map((c) => c.amount), 1);

  return (
    <div className="flex flex-col h-full bg-[#121212] text-neutral-200" id="movements-container">
      {/* Search and stats bar */}
      <div className="p-4 bg-zinc-900 border-b border-zinc-800 shrink-0" id="movements-header">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-1.5">
            Saldos y Movimientos <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
          </h3>
          <button 
            onClick={onClose} 
            className="p-1 text-zinc-400 hover:text-white rounded-full bg-zinc-800 hover:bg-zinc-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mini Balance summary of state */}
        <div className="grid grid-cols-2 gap-2 mb-3 text-center" id="movements-summary-cards">
          <div className="p-2 bg-zinc-950/80 rounded-xl border border-zinc-800/60">
            <span className="text-[9px] text-zinc-500 uppercase font-semibold">Total Ingresos</span>
            <div className="text-xs font-bold text-emerald-400 flex items-center justify-center gap-0.5">
              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              +${totalIngresos.toLocaleString("es-CO")}
            </div>
          </div>
          <div className="p-2 bg-zinc-950/80 rounded-xl border border-zinc-800/60">
            <span className="text-[9px] text-zinc-500 uppercase font-semibold">Total Gastos</span>
            <div className="text-xs font-bold text-rose-400 flex items-center justify-center gap-0.5">
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              -${totalEgresos.toLocaleString("es-CO")}
            </div>
          </div>
        </div>

        {/* Dynamic customized category analytics chart using native flex items */}
        <div className="p-3 bg-zinc-950/50 rounded-xl border border-zinc-800/40 mb-3" id="expenses-category-graph">
          <h4 className="text-[10px] text-zinc-400 font-bold uppercase mb-2">Resumen de Gastos por Categoría</h4>
          {categorySummary.length === 0 ? (
            <p className="text-[10px] text-zinc-600 text-center py-1">No hay gastos para graficar de momento.</p>
          ) : (
            <div className="space-y-1.5">
              {categorySummary.map((item) => {
                const percentage = Math.round((item.amount / totalEgresos) * 100) || 0;
                const barWidth = Math.max(10, Math.round((item.amount / maxExpense) * 100));
                
                // Color mapping code
                let colorClass = "bg-neutral-500";
                if (item.category === "Mercado") colorClass = "bg-orange-400";
                else if (item.category === "Entretenimiento") colorClass = "bg-violet-400";
                else if (item.category === "Servicios") colorClass = "bg-blue-400";
                else if (item.category === "Transferencia") colorClass = "bg-emerald-400";
                else if (item.category === "Otros") colorClass = "bg-zinc-400";

                return (
                  <div key={item.category} className="text-[10px] space-y-0.5">
                    <div className="flex justify-between text-zinc-300">
                      <span className="font-medium">{item.category}</span>
                      <span className="font-mono text-zinc-500">
                        ${item.amount.toLocaleString("es-CO")} ({percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                      <div className={`h-full ${colorClass} rounded-full`} style={{ width: `${barWidth}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Filtering inputs */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-zinc-500" />
            <input
              type="text"
              placeholder="Buscar movimiento..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-950 text-xs pl-8 pr-3 py-2 rounded-lg border border-zinc-500/25 text-neutral-100 placeholder-zinc-500 focus:outline-none focus:border-yellow-400"
            />
          </div>
        </div>

        {/* Horizontal scroll index for categories */}
        <div className="flex gap-1.5 overflow-x-auto whitespace-nowrap pt-2.5 scrollbar-none" id="categories-tabs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-full text-[9px] font-semibold tracking-wide transition-all cursor-pointer ${
                selectedCategory === cat
                  ? "bg-yellow-400 text-stone-950 font-bold"
                  : "bg-zinc-950 text-zinc-400 border border-zinc-800 hover:text-white"
              }`}
            >
              {cat === "TODAS" ? "Todas" : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Movements list scroll viewport */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-[#121212]" id="movements-list">
        {filteredMovements.length === 0 ? (
          <div className="py-12 text-center" id="empty-movements">
            <Filter className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
            <p className="text-xs text-zinc-500">No se encontraron movimientos registrados.</p>
          </div>
        ) : (
          filteredMovements.map((mov) => {
            const isIngreso = mov.type === "ingreso";
            
            // Icon color styling
            let badgeBg = "bg-zinc-800/80";
            let badgeText = "text-zinc-300";
            if (mov.category === "Nómina") { badgeBg = "bg-emerald-950/40"; badgeText = "text-emerald-400"; }
            else if (mov.category === "Mercado") { badgeBg = "bg-amber-950/40"; badgeText = "text-amber-400"; }
            else if (mov.category === "Entretenimiento") { badgeBg = "bg-purple-950/40"; badgeText = "text-purple-400"; }
            else if (mov.category === "Servicios") { badgeBg = "bg-blue-950/40"; badgeText = "text-blue-400"; }

            return (
              <div 
                key={mov.id} 
                className="p-3 bg-zinc-900 border border-zinc-800/80 rounded-xl flex items-center justify-between gap-3 text-xs hover:border-zinc-700 transition-colors"
              >
                {/* Visual arrow identifier */}
                <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center ${
                  isIngreso ? "bg-emerald-950/60 text-emerald-400" : "bg-rose-950/60 text-rose-400"
                }`}>
                  {isIngreso ? (
                    <ArrowDownLeft className="w-4 h-4 shrink-0 animate-pulse" />
                  ) : (
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  )}
                </div>

                {/* Description details content */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-neutral-200 truncate">{mov.description}</h4>
                  <div className="flex gap-2 items-center text-[9px] mt-0.5 text-zinc-500">
                    <span>{mov.date}</span>
                    <span className={`px-1.5 py-0.2 rounded font-medium ${badgeBg} ${badgeText}`}>
                      {mov.category}
                    </span>
                  </div>
                </div>

                {/* Money indicator */}
                <span className={`font-mono font-bold text-right text-xs shrink-0 ${
                  isIngreso ? "text-emerald-400" : "text-neutral-200"
                }`}>
                  {isIngreso ? "+" : "-"}${mov.amount.toLocaleString("es-CO")}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
