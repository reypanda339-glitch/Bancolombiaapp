import React, { useState, useEffect } from "react";
import { Camera, RefreshCw, X, Sparkles, UserCheck, Check } from "lucide-react";

interface QRViewProps {
  onScanSuccess: (amount: number, destName: string, destAccount: string) => void;
  onClose: () => void;
}

export default function QRView({ onScanSuccess, onClose }: QRViewProps) {
  const [scanState, setScanState] = useState<"scanning" | "success">("scanning");
  const [scannedMerchant, setScannedMerchant] = useState("");
  const [scannedAmount, setScannedAmount] = useState(0);

  useEffect(() => {
    // Auto simulate a scan detection after 3 seconds just for great micro-interaction!
    const timer = setTimeout(() => {
      handleAutoDetectQR();
    }, 4500);

    return () => clearTimeout(timer);
  }, []);

  const handleAutoDetectQR = () => {
    setScannedMerchant("Cafetería Juan Valdez Poblado");
    setScannedAmount(18500);
    setScanState("success");
  };

  const handleConfirmQRTransfer = () => {
    onScanSuccess(scannedAmount, scannedMerchant, "987510294-NEQUI");
  };

  return (
    <div className="flex flex-col h-full bg-black text-neutral-200" id="qr-scanner-overlay">
      {/* Top action bar */}
      <div className="p-4 bg-zinc-900/90 flex justify-between items-center shrink-0">
        <h3 className="text-xs font-bold text-neutral-100 flex items-center gap-1">
          Escáner QR Bancolombia <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
        </h3>
        <button
          onClick={onClose}
          className="p-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-between p-6">
        {scanState === "scanning" ? (
          <div className="space-y-6 text-center flex-1 flex flex-col justify-center">
            {/* Simulated camera viewfinder frame */}
            <div className="relative w-64 h-64 mx-auto border-2 border-dashed border-zinc-700 rounded-3xl overflow-hidden flex items-center justify-center bg-zinc-950/40 shadow-inner">
              
              {/* Animated scan line */}
              <div className="absolute left-0 right-0 h-0.5 bg-yellow-400 animate-bounce top-1/4 shadow-md shadow-yellow-400/50"></div>

              {/* Viewfinder corner brackets */}
              <div className="absolute top-4 left-4 w-6 h-6 border-t-4 border-l-4 border-yellow-400 rounded-tl-md"></div>
              <div className="absolute top-4 right-4 w-6 h-6 border-t-4 border-r-4 border-yellow-400 rounded-tr-md"></div>
              <div className="absolute bottom-4 left-4 w-6 h-6 border-b-4 border-l-4 border-yellow-400 rounded-bl-md"></div>
              <div className="absolute bottom-4 right-4 w-6 h-6 border-b-4 border-r-4 border-yellow-400 rounded-br-md"></div>

              <div className="text-center space-y-1 z-10 p-4">
                <Camera className="w-10 h-10 text-zinc-600 mx-auto animate-pulse" />
                <p className="text-[10px] text-zinc-400">Canal de lectura dinámico</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold text-neutral-200">Apunta al código QR para pagar o transferir</p>
              <p className="text-[10px] text-zinc-500 max-w-[280px] mx-auto leading-normal">
                Soporta códigos impresos en datáfonos, locales comerciales, tarjetas de presentación de cuentas Bancolombia, Nequi y Daviplata.
              </p>
            </div>

            <button
              onClick={handleAutoDetectQR}
              className="px-4 py-2 bg-zinc-900 border border-zinc-800 hover:border-yellow-400 text-yellow-400 text-[10px] font-bold rounded-lg mx-auto inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              Simular escaneo de QR comercial
            </button>
          </div>
        ) : (
          /* Success scanning detection state display */
          <div className="space-y-6 text-center flex-1 flex flex-col justify-center">
            <div className="w-16 h-16 bg-emerald-950/50 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
              <UserCheck className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider">Código de Recaudo Detectado</span>
              <h3 className="text-sm font-bold text-neutral-200">{scannedMerchant}</h3>
              <p className="text-[10px] text-zinc-500 font-mono">Destino: Cuenta Nequi / REF-98751</p>
            </div>

            {/* Charge confirmation card */}
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl max-w-xs mx-auto">
              <span className="text-[10px] text-zinc-500 uppercase block">Cobro Solicitado</span>
              <span className="text-xl font-bold text-yellow-400 font-mono">${scannedAmount.toLocaleString("es-CO")} COP</span>
            </div>

            <div className="space-y-2 max-w-xs mx-auto w-full pt-4">
              <button
                onClick={handleConfirmQRTransfer}
                className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <Check className="w-4 h-4" /> Proceder al Pago Simulado
              </button>
              <button
                onClick={() => setScanState("scanning")}
                className="w-full py-2 bg-transparent text-zinc-400 hover:text-white text-xs cursor-pointer"
              >
                Reintentar escanear
              </button>
            </div>
          </div>
        )}

        <div className="text-zinc-600 text-[9px] text-center">
          Tecnología de lectura encriptada Bancolombia QR S.A.
        </div>
      </div>
    </div>
  );
}
