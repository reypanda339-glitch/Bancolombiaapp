import React, { useState } from "react";
import { ArrowLeft, CheckCircle, Share2, Clipboard, ChevronDown, Landmark, Sparkles } from "lucide-react";
import { BankAccount } from "../types";

interface TransferViewProps {
  accounts: BankAccount[];
  onExecuteTransfer: (fromAccountId: string, amount: number, destAccount: string, desc: string) => void;
  onClose: () => void;
}

export default function TransferView({ accounts, onExecuteTransfer, onClose }: TransferViewProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Info, 2: Confirm, 3: Success Receipt
  const [fromAccount, setFromAccount] = useState(accounts[0]?.id || "");
  const [destName, setDestName] = useState("");
  const [destAccount, setDestAccount] = useState("");
  const [destBank, setDestBank] = useState("Bancolombia");
  const [amountInput, setAmountInput] = useState("");
  const [description, setDescription] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const activeFromAcc = accounts.find((a) => a.id === fromAccount);

  const registeredContacts = [
    { name: "Juan Pérez (Amigo)", account: "505432190", bank: "Bancolombia" },
    { name: "María Gómez (Mamá)", account: "0012345678", bank: "Bancolombia" },
    { name: "Inmobiliaria (Arriendo)", account: "987654321", bank: "Banco de Bogotá" }
  ];

  const handleSelectContact = (contact: typeof registeredContacts[0]) => {
    setDestName(contact.name);
    setDestAccount(contact.account);
    setDestBank(contact.bank);
  };

  const handleNextStep1 = () => {
    setErrorMessage("");
    const amt = parseFloat(amountInput.replace(/\./g, "").trim());

    if (!destName.trim()) {
      setErrorMessage("Digita el nombre del destinatario.");
      return;
    }
    if (!destAccount.trim()) {
      setErrorMessage("Digita el número de cuenta de destino.");
      return;
    }
    if (isNaN(amt) || amt <= 0) {
      setErrorMessage("Por favor digita un monto válido mayor a cero.");
      return;
    }
    if (activeFromAcc && amt > activeFromAcc.balance) {
      setErrorMessage("Fondos insuficientes en la cuenta seleccionada.");
      return;
    }

    setStep(2);
  };

  const handleConfirmTransfer = () => {
    const amt = parseFloat(amountInput.replace(/\./g, "").trim());
    onExecuteTransfer(fromAccount, amt, `${destBank} - ${destAccount} (${destName})`, description || "Transferencia portal móvil");
    setStep(3);
  };

  const handleCloseReceipt = () => {
    onClose();
  };

  // Safe formatting for cash as they type
  const handleAmountChange = (val: string) => {
    const cleanNumbers = val.replace(/\D/g, "");
    if (!cleanNumbers) {
      setAmountInput("");
      return;
    }
    setAmountInput(parseInt(cleanNumbers).toLocaleString("es-CO"));
  };

  return (
    <div className="flex flex-col h-full bg-[#121212] text-neutral-200" id="transfer-wizard">
      {/* Header bar and navigation */}
      <div className="px-4 py-3 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between shrink-0">
        <button
          onClick={step === 2 ? () => setStep(1) : onClose}
          className="p-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-yellow-400 cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold text-neutral-100 uppercase tracking-wider">
          {step === 3 ? "Comprobante" : "Transferir plata"}
        </span>
        <div className="w-7 h-7" /> {/* Spacer */}
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col justify-between">
        {step === 1 && (
          <div className="space-y-4" id="transfer-step-1">
            {/* Source Account Choice */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-500 font-bold uppercase">Cuenta de Origen</label>
              <div className="relative">
                <select
                  value={fromAccount}
                  onChange={(e) => setFromAccount(e.target.value)}
                  className="w-full bg-zinc-950 text-xs px-3 py-2.5 rounded-xl border border-zinc-800 focus:border-yellow-400 focus:outline-none appearance-none cursor-pointer"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.type} {acc.name} (${acc.balance.toLocaleString("es-CO")} COP)
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3.5 top-3.5 w-4 h-4 text-zinc-500 pointer-events-none" />
              </div>
            </div>

            {/* Quick Contacts Shortcuts */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-500 font-bold uppercase">Destinatarios Frecuentes</label>
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                {registeredContacts.map((contact, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectContact(contact)}
                    className="p-2.5 bg-zinc-900 hover:border-yellow-400 border border-zinc-800/80 rounded-xl text-left cursor-pointer shrink-0 min-w-[120px]"
                  >
                    <p className="font-bold text-[10px] text-neutral-100 truncate">{contact.name}</p>
                    <p className="text-[9px] text-zinc-500 truncate">{contact.bank}</p>
                    <p className="text-[9px] font-mono text-zinc-500">{contact.account}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Destination form fields */}
            <div className="space-y-3 bg-zinc-900/40 p-3.5 rounded-2xl border border-zinc-800/60">
              <div className="space-y-1">
                <label className="text-[10px] text-zinc-500 font-bold uppercase">Nombre Destinatario</label>
                <input
                  type="text"
                  placeholder="Ej. Alejandra Castro"
                  value={destName}
                  onChange={(e) => setDestName(e.target.value)}
                  className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500 font-bold uppercase">Nº de Cuenta</label>
                  <input
                    type="text"
                    placeholder="23456789"
                    value={destAccount}
                    onChange={(e) => setDestAccount(e.target.value)}
                    className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-700 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500 font-bold uppercase">Banco</label>
                  <select
                    value={destBank}
                    onChange={(e) => setDestBank(e.target.value)}
                    className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400"
                  >
                    <option value="Bancolombia">Bancolombia</option>
                    <option value="Nequi">Nequi</option>
                    <option value="Daviplata">Daviplata</option>
                    <option value="Davivienda">Davivienda</option>
                    <option value="Banco de Bogotá">Banco de Bogotá</option>
                    <option value="ScotiaBank">Colpatria</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Amount input */}
            <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800/80 text-center space-y-1">
              <label className="text-[10px] text-zinc-500 font-bold uppercase block">¿Cuánto quieres enviar?</label>
              <div className="flex items-center justify-center gap-1">
                <span className="text-xl font-bold text-yellow-400">$</span>
                <input
                  type="text"
                  placeholder="0.00"
                  value={amountInput}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  className="bg-transparent text-2xl font-bold font-mono text-neutral-100 max-w-[200px] border-none focus:outline-none text-center"
                />
              </div>
              <span className="text-[9px] text-zinc-600 block">Pesos Colombianos (COP)</span>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 font-bold uppercase">Mensaje (Opcional)</label>
              <input
                type="text"
                placeholder="Ej. Regalo de cumpleaños"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-950 text-xs px-3 py-2 rounded-xl border border-zinc-800 text-neutral-200 focus:outline-none focus:border-yellow-400 placeholder-zinc-700"
              />
            </div>

            {errorMessage && (
              <p className="text-rose-400 text-[10px] text-center font-medium font-sans">{errorMessage}</p>
            )}

            <button
              onClick={handleNextStep1}
              className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs tracking-wider uppercase transition-colors cursor-pointer mt-4"
            >
              Continuar
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5" id="transfer-step-2">
            <div className="text-center py-4">
              <Landmark className="w-10 h-10 text-yellow-400 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-neutral-200">Revisa la información de tu transferencia</h3>
              <p className="text-[10px] text-neutral-500 mt-1">El dinero se transferirá de manera inmediata.</p>
            </div>

            {/* Confirmation parameters card */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-3.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-500">Monto a Enviar:</span>
                <span className="font-mono font-bold text-yellow-400 text-sm">${amountInput} COP</span>
              </div>
              <hr className="border-zinc-800/60" />
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Desde la cuenta:</span>
                  <span className="font-semibold text-neutral-200">{activeFromAcc?.type} {activeFromAcc?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Destinatario:</span>
                  <span className="font-semibold text-neutral-200">{destName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Cuenta Destino:</span>
                  <span className="font-semibold font-mono text-neutral-200">{destAccount} ({destBank})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Comisión:</span>
                  <span className="font-semibold text-emerald-400">Gratis ($0 COP)</span>
                </div>
                {description && (
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Mensaje:</span>
                    <span className="text-neutral-400 italic font-mono">"{description}"</span>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-4 space-y-2">
              <button
                onClick={handleConfirmTransfer}
                className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs tracking-wider uppercase transition-colors cursor-pointer"
              >
                Confirmar y Enviar Plata
              </button>
              <button
                onClick={() => setStep(1)}
                className="w-full py-2.5 bg-transparent border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800/40 font-bold rounded-xl text-xs transition-all cursor-pointer"
              >
                Volver a corregir
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4" id="transfer-step-3">
            {/* Highly faithful digital receipt layout of Bancolombia */}
            <div className="bg-stone-900 border border-zinc-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden" id="digital-receipt-card">
              {/* Subtle top brand yellow bar decor */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-yellow-400"></div>

              <div className="text-center space-y-1.5 pt-2">
                <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h3 className="text-neutral-200 font-bold text-sm">Transacción Exitosa</h3>
                <span className="text-[10px] text-zinc-500 mt-0.5 inline-block font-mono">ID: {Math.floor(Math.random() * 90000000 + 10000000)}</span>
              </div>

              {/* Big cash display */}
              <div className="py-4 text-center">
                <span className="text-[9px] text-zinc-500 uppercase block">Transferido</span>
                <span className="text-xl font-bold font-mono text-yellow-400">${amountInput} COP</span>
                <span className="text-[9px] text-emerald-400 font-medium block mt-1">Sin Costo ($0 COP)</span>
              </div>

              <hr className="border-dashed border-zinc-800 pb-3" />

              <div className="space-y-2 text-[10px] text-neutral-300">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Fecha y Hora:</span>
                  <span className="font-mono">{new Date().toLocaleString("es-CO")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Origen:</span>
                  <span>{activeFromAcc?.type} {activeFromAcc?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Destino:</span>
                  <span className="truncate max-w-[150px] font-medium">{destName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Banco del receptor:</span>
                  <span>{destBank}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Cuenta del receptor:</span>
                  <span className="font-mono">{destAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Concepto:</span>
                  <span className="truncate max-w-[150px] italic">"{description || "Transferencia móvil"}"</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-800 text-center">
                <p className="text-[9px] text-zinc-500">Bancolombia S.A. • Nit 890.903.938-8</p>
                <p className="text-[9px] text-amber-500 font-semibold flex items-center justify-center gap-1 mt-1">
                  <Sparkles className="w-3 h-3" /> Simulación de aprendizaje segura
                </p>
              </div>
            </div>

            {/* Actions for receipt */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  alert("Simulado: Comprobante guardado en fotos de tu dispositivo ficticio.");
                }}
                className="w-full py-2.5 bg-zinc-900 border border-zinc-800 hover:border-yellow-400 text-neutral-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Clipboard className="w-4 h-4 text-yellow-400" />
                Guardar Comprobante
              </button>
              <button
                onClick={handleCloseReceipt}
                className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl text-xs tracking-wider uppercase transition-colors cursor-pointer"
              >
                Volver a Inicio
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
