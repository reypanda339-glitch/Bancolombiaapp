export interface BankAccount {
  id: string;
  name: string;
  type: "Ahorros" | "Corriente";
  number: string;
  balance: number;
}

export interface BankMovement {
  id: string;
  description: string;
  amount: number;
  date: string;
  category: "Mercado" | "Entretenimiento" | "Servicios" | "Transferencia" | "Nómina" | "Otros";
  type: "egreso" | "ingreso";
}

export interface Bolsillo {
  id: string;
  name: string;
  targetAmount: number;
  savedAmount: number;
  category: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  filePath?: string; // Optional field for analyzed documents
}
